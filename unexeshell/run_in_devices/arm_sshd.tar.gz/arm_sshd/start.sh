mkdir /var/empty                                                                                                       
echo "sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin" >> /etc/passwd                               
cp etc/* /usr/local/etc/                                                                                               
passwd root                                                                                                            
/facerecodb/zhanghaolong/arm_sshd/bin/sshd
