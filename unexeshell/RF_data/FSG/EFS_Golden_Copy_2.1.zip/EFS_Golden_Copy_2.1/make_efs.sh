#!/bin/sh

if [ -f fs_image.tar.gz ]; then
	rm ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/fs_image.tar.gz
	rm ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/fs_image.tar.gz.mbn
	rm ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/mbn_fs_image.tar.gz
	cp fs_image.tar.gz ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/
else
	echo "fs_image.tar.gz not exist!!"
	exit 0
fi

if [ -f ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/fs_image.tar.gz ] ; then
	python ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/QDSTMBN.py fs_image.tar.gz
	sleep 3
	echo "sign finished"
else
	echo "not copyed into qdst!!!"
	exit 0
fi

if [ -f ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/fs_image.tar.gz.mbn ] ; then
	cp ../msm8939-la-2-1/modem_proc/core/storage/tools/qdst/fs_image.tar.gz.mbn .
else
	echo "sign falied !!!"
	exit 0
fi

if [ -f efs_image_create.py ] | [ -f efs_image_meta.bin ] | [ -f efs_image_dictionary.py ] | [ -f efs_image_dictionary.pyc ] | [ -f efs_image_header_gen.py ] | [ -f efs_image_header_gen.pyc ] ; then
	python efs_image_create.py efs_image_meta.bin fs_image.tar.gz.mbn
	sleep 3
else
	echo "efs create file not exits!!"
	exit 0
fi

if [ -f fs_image.tar.gz.mbn.img ] ; then
	echo "make successful"
else
	echo "make failed!!"
fi



