#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <android/log.h>
#include <cutils/log.h>
#include <cutils/xlog.h>

#define LOG_TAG "mycputest"
#define TOUCH_FW_UPDATE_NODE "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq"

int main()
{
	int fd, update_or_not = 0;
	int buf[10];
	int try_count = 50;

	do{
		fd = open(TOUCH_FW_UPDATE_NODE, O_RDONLY);
		ALOGD("ektf2k update FW service  start ...%s:[%d].\n", __func__, __LINE__);
		if(fd == -1)
		{
			ALOGE("open TOUCH_FW_UPDATE_NODE failed reason = %s \n", strerror(errno));	
			return 0;
		}

		if(read(fd, buf, sizeof(buf)) == -1)
		{
			ALOGE("read fd errno \n");
			return 0;
		}
		close(fd);
		ALOGD("buf = %d.%s:[%d]\n", buf[0], __func__, __LINE__);
		sleep(1);
	}while(try_count --> 0);

	return 0;

}

